﻿using System;
using System.IO;
using System.Net;
using System.Text;

namespace PopProject.Util
{
    internal class HttpClient_util
    {
        private readonly string url = "http://hipackcom.co.kr";



        public HttpClient_util(string commend)
        {
            url += "/" + commend;
        }
        public HttpClient_util(string url, string jsonData)
        {

            this.url = url;
            _ = SendLog(jsonData);
        }

        public string SendHttp(string sendMessage)
        {
            string result = string.Empty;
            try
            {

                Uri uri = new Uri(url);
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = WebRequestMethods.Http.Post;
                request.Timeout = 5000;

                byte[] data = Encoding.UTF8.GetBytes(sendMessage);
                request.ContentType = "application/json; charset=utf-8";
                request.ContentLength = data.Length;

                // 전송 처리 
                Stream dataStream = request.GetRequestStream();
                dataStream.Write(data, 0, data.Length);
                dataStream.Close();

                //응답 처리
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream responseStream = response.GetResponseStream();
                StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8);
                result = streamReader.ReadToEnd();

                streamReader.Close();
                responseStream.Close();
                response.Close();

            }

            catch (Exception e)

            {
                Console.WriteLine(e.Message);
                return result;
            }

            Console.WriteLine("전송 값 " + url + sendMessage);
            Console.WriteLine("응답 값 : " + result);
            return result;
        }

        public string SendLog(string sendMessage)
        {
            string result = string.Empty;
            try
            {
                Uri uri = new Uri(url);
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = WebRequestMethods.Http.Post;
                request.Timeout = 5000;
                request.ContentType = "application/json; charset=utf-8";


                // 전송 처리 
                Stream dataStream = request.GetRequestStream();
                dataStream.Close();

                //응답 처리
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Stream responseStream = response.GetResponseStream();
                StreamReader streamReader = new StreamReader(responseStream, Encoding.UTF8);
                result = streamReader.ReadToEnd();

                streamReader.Close();
                responseStream.Close();
                response.Close();

            }

            catch (Exception e)

            {
                Console.WriteLine(e.Message);
                return result;
            }

            Console.WriteLine("전송 값 " + url + sendMessage);
            Console.WriteLine("응답 값 : " + result);

            return result;
        }
    }
}
