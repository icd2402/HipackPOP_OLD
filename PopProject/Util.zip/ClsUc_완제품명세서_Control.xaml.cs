﻿using System;
using System.ComponentModel;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using KeepDynamic.Barcode.Generator;

namespace PopProject.Util
{
    /// <summary>
    /// ClsUc_완제품명세서_Control.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ClsUc_완제품명세서_Control : UserControl
    {
        public ProductReport ViewModel = new ProductReport();


        public ClsUc_완제품명세서_Control()
        {

            InitializeComponent();
            barcodeImage.Visibility = System.Windows.Visibility.Hidden;

        }

        public void Set_BarCode()
        {

            DataContext = ViewModel;
            if (Convert.ToInt32(ViewModel.PStockKey) > 0)
            {

                barcodeImage.Visibility = System.Windows.Visibility.Visible;
                BarCode barcodeFont = new BarCode
                {
                    SymbologyType = SymbologyType.Code128c,
                    X = 3,
                    BarCodeWidth = 450,
                    BarCodeHeight = 150,
                    CodeText = ViewModel.PStockKey
                };
                System.IO.Stream stream = new System.IO.MemoryStream();
                barcodeFont.drawBarcode(stream);

                BitmapImage imageSource = new BitmapImage();
                imageSource.BeginInit();
                imageSource.StreamSource = stream;
                imageSource.EndInit();
                barcodeImage.Source = imageSource;

            }
        }

        public class ProductReport
        {

            public event PropertyChangedEventHandler PropertyChanged;
            public delegate void PropertyChangedEventHandler(object sender, PropertyChangedEventArgs e);

            protected virtual void OnPropertyChanged(string propName)
            {
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
            }

            private string _customSName;

            public string CustomSName
            {
                get => _customSName;
                set
                {
                    _customSName = value;
                    OnPropertyChanged("customSName");
                }
            }

            private string _prodName;
            public string ProdName
            {

                get => _prodName;

                set
                {
                    _prodName = value;
                    OnPropertyChanged("prodName");
                }
            }

            private DateTime _orderLast;
            public DateTime OrderLast
            {
                get => _orderLast;
                set
                {
                    _orderLast = value;
                    OnPropertyChanged("orderLast");
                }
            }

            private string _pSize;
            public string PSize
            {
                get => _pSize;
                set
                {
                    _pSize = value;
                    OnPropertyChanged("pSize");
                }
            }

            private string _pMemo;
            public string PMemo
            {
                get => _pMemo;
                set
                {
                    _pMemo = value;
                    OnPropertyChanged("pMemo");
                }
            }

            private DateTime _pworkDate;
            public DateTime PworkDate
            {
                get => _pworkDate;
                set
                {
                    _pworkDate = value;
                    OnPropertyChanged("pworkDate");
                }
            }

            private int _resultCount;
            public int ResultCount
            {
                get => _resultCount;
                set
                {
                    _resultCount = value;
                    OnPropertyChanged("resultCount");
                }
            }

            private string _pStockKey;
            public string PStockKey
            {

                get => _pStockKey;

                set
                {
                    _pStockKey = value;
                    OnPropertyChanged("pStockKey");
                }
            }

            private string _MycustomSName;
            public string MycustomSName
            {

                get => _MycustomSName;

                set
                {
                    _MycustomSName = value;
                    OnPropertyChanged("MycustomSName");
                }
            }
        }
    }
}
