﻿using System;

namespace PopProject.Util
{
    internal class ReturnModel
    {
        public int 결과 { get; set; } = 0;

        public string 리턴값 { get; set; } = "";
    }
}
