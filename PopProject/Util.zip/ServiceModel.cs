﻿using System;

namespace PopProject.Util
{
    internal class ServiceModel
    {
        public static string[] 접속정보 = new string[] { Properties.Settings.Default.corp_id, Properties.Settings.Default.UserID, Properties.Settings.Default.UserName };

        //오주
        public static ServiceReference_ojbox.Service_CRUDClient oj_Service;
        public static ServiceReference_ojbox.DBHandle_Model oj_DB_Handle_Model;
        public static ServiceReference_ojbox.Access_Model oj_Access_Model;
        public static ServiceReference_ojbox.Return_Model oj_Return_Model;

        //미래
        public static ServiceReference_mirae.Service_CRUDClient mirae_Service;
        public static ServiceReference_mirae.DBHandle_Model mirae_DB_Handle_Model;
        public static ServiceReference_mirae.Access_Model mirae_Access_Model;
        public static ServiceReference_mirae.Return_Model mirae_Return_Model;

        //광성
        public static ServiceReference_ksbox.Service_CRUDClient Ks_Service;
        public static ServiceReference_ksbox.DBHandle_Model ks_DB_Handle_Model;
        public static ServiceReference_ksbox.Access_Model ks_Access_Model;
        public static ServiceReference_ksbox.Return_Model ks_Return_Model;

        //하나
        public static ServiceReference_hnbox.Service_CRUDClient hn_Service;
        public static ServiceReference_hnbox.DBHandle_Model hn_DB_Handle_Model;
        public static ServiceReference_hnbox.Access_Model hn_Access_Model;
        public static ServiceReference_hnbox.Return_Model hn_Return_Model;

        //선호
        public static ServiceReference_shbox.Service_CRUDClient sh_Service;
        public static ServiceReference_shbox.DBHandle_Model sh_DB_Handle_Model;
        public static ServiceReference_shbox.Access_Model sh_Access_Model;
        public static ServiceReference_shbox.Return_Model sh_Return_Model;

        //광무
        public static ServiceReference_kmbox.Service_CRUDClient km_Service;
        public static ServiceReference_kmbox.DBHandle_Model km_DB_Handle_Model;
        public static ServiceReference_kmbox.Access_Model km_Access_Model;
        public static ServiceReference_kmbox.Return_Model km_Return_Model;

        //유창
        public static ServiceReference_ycbox.Service_CRUDClient yc_Service;
        public static ServiceReference_ycbox.DBHandle_Model yc_DB_Handle_Model;
        public static ServiceReference_ycbox.Access_Model yc_Access_Model;
        public static ServiceReference_ycbox.Return_Model yc_Return_Model;

        public static void ServiceModelClean(string serverIndex)
        {
            Console.WriteLine("serverIndex : " + serverIndex);
            switch (serverIndex)
            {

                case "ojbox":
                    oj_Service = new ServiceReference_ojbox.Service_CRUDClient();
                    oj_Access_Model = new ServiceReference_ojbox.Access_Model();
                    oj_Return_Model = new ServiceReference_ojbox.Return_Model();
                    oj_DB_Handle_Model = new ServiceReference_ojbox.DBHandle_Model
                    {
                        접속정보 = 접속정보,
                        BroadCasting = 0,
                        BroadCastingName = string.Empty,
                        inputPkey = "0",
                        inputContent = string.Empty,
                        inputProcessContent = string.Empty
                    };

                    break;
                case "miraebox":

                    mirae_Service = new ServiceReference_mirae.Service_CRUDClient();
                    mirae_Access_Model = new ServiceReference_mirae.Access_Model();
                    mirae_Return_Model = new ServiceReference_mirae.Return_Model();
                    mirae_DB_Handle_Model = new ServiceReference_mirae.DBHandle_Model
                    {
                        접속정보 = 접속정보,
                        BroadCasting = 0,
                        BroadCastingName = string.Empty,
                        inputPkey = 0,
                        inputContent = string.Empty,
                        inputProcessContent = string.Empty
                    };

                    break;

                case "ksbox":

                    Ks_Service = new ServiceReference_ksbox.Service_CRUDClient();
                    ks_Access_Model = new ServiceReference_ksbox.Access_Model();
                    ks_Return_Model = new ServiceReference_ksbox.Return_Model();
                    ks_DB_Handle_Model = new ServiceReference_ksbox.DBHandle_Model
                    {
                        접속정보 = 접속정보,
                        BroadCasting = 0,
                        BroadCastingName = string.Empty,
                        inputPkey = "0",
                        inputContent = string.Empty,
                        inputProcessContent = string.Empty
                    };

                    break;

                case "hnbox":

                    hn_Service = new ServiceReference_hnbox.Service_CRUDClient();
                    hn_Access_Model = new ServiceReference_hnbox.Access_Model();
                    hn_Return_Model = new ServiceReference_hnbox.Return_Model();
                    hn_DB_Handle_Model = new ServiceReference_hnbox.DBHandle_Model
                    {
                        접속정보 = 접속정보,
                        BroadCasting = 0,
                        BroadCastingName = string.Empty,
                        inputPkey = "0",
                        inputContent = string.Empty,
                        inputProcessContent = string.Empty
                    };

                    break;

                case "shbox":

                    sh_Service = new ServiceReference_shbox.Service_CRUDClient();
                    sh_Access_Model = new ServiceReference_shbox.Access_Model();
                    sh_Return_Model = new ServiceReference_shbox.Return_Model();
                    sh_DB_Handle_Model = new ServiceReference_shbox.DBHandle_Model
                    {
                        접속정보 = 접속정보,
                        BroadCasting = 0,
                        BroadCastingName = string.Empty,
                        inputPkey = "0",
                        inputContent = string.Empty,
                        inputProcessContent = string.Empty
                    };

                    break;

                case "kmbox":

                    km_Service = new ServiceReference_kmbox.Service_CRUDClient();
                    km_Access_Model = new ServiceReference_kmbox.Access_Model();
                    km_Return_Model = new ServiceReference_kmbox.Return_Model();
                    km_DB_Handle_Model = new ServiceReference_kmbox.DBHandle_Model
                    {
                        접속정보 = 접속정보,
                        BroadCasting = 0,
                        BroadCastingName = string.Empty,
                        inputPkey = "0",
                        inputContent = string.Empty,
                        inputProcessContent = string.Empty
                    };

                    break;

                case "ycbox":

                    yc_Service = new ServiceReference_ycbox.Service_CRUDClient();
                    yc_Access_Model = new ServiceReference_ycbox.Access_Model();
                    yc_Return_Model = new ServiceReference_ycbox.Return_Model();
                    yc_DB_Handle_Model = new ServiceReference_ycbox.DBHandle_Model
                    {
                        접속정보 = 접속정보,
                        BroadCasting = 0,
                        BroadCastingName = string.Empty,
                        inputPkey = "0",
                        inputContent = string.Empty,
                        inputProcessContent = string.Empty
                    };

                    break;
                default:
                    break;
            }
        }

        public static ReturnModel GetData(string serverIndex, string SP명, string[] 파라미터, object[] 값, int 갱신)
        {
            ReturnModel returnModel = new ReturnModel();
            try
            {
                switch (serverIndex)
                {
                    case "ojbox":
                        oj_Access_Model.SP명 = SP명;
                        oj_Access_Model.파라미터 = 파라미터;
                        oj_Access_Model.값 = 값;
                        oj_DB_Handle_Model.프로시저 = new ServiceReference_ojbox.Access_Model[1] { oj_Access_Model };

                        oj_Return_Model = 갱신 == 1 ? oj_Service.갱신(oj_DB_Handle_Model, 갱신) : oj_Service.조회(oj_DB_Handle_Model);

                        returnModel.결과 = oj_Return_Model.결과;
                        returnModel.리턴값 = oj_Return_Model.Retrun값;
                        Console.WriteLine(SP명 + " 리턴결과 : " + oj_Return_Model.결과);
                        Console.WriteLine(SP명 + " 리턴값 : " + oj_Return_Model.Retrun값);
                        break;
                    case "miraebox":

                        mirae_Access_Model.SP명 = SP명;
                        mirae_Access_Model.파라미터 = 파라미터;
                        mirae_Access_Model.값 = 값;
                        mirae_DB_Handle_Model.프로시저 = new ServiceReference_mirae.Access_Model[1] { mirae_Access_Model };

                        mirae_Return_Model = 갱신 == 1 ? mirae_Service.갱신(mirae_DB_Handle_Model, 갱신) : mirae_Service.조회(mirae_DB_Handle_Model);

                        returnModel.결과 = mirae_Return_Model.결과;
                        returnModel.리턴값 = mirae_Return_Model.Retrun값;
                        // Console.WriteLine(SP명 + " 리턴결과 : " + mirae_Return_Model.결과);
                        // Console.WriteLine(SP명 + " 리턴값 : " + mirae_Return_Model.Retrun값);

                        break;

                    case "ksbox":

                        ks_Access_Model.SP명 = SP명;
                        ks_Access_Model.파라미터 = 파라미터;
                        ks_Access_Model.값 = 값;
                        ks_DB_Handle_Model.프로시저 = new ServiceReference_ksbox.Access_Model[1] { ks_Access_Model };

                        ks_Return_Model = 갱신 == 1 ? Ks_Service.갱신(ks_DB_Handle_Model, 갱신) : Ks_Service.조회(ks_DB_Handle_Model);

                        returnModel.결과 = ks_Return_Model.결과;
                        returnModel.리턴값 = ks_Return_Model.Retrun값;

                        // Console.WriteLine(SP명 + " 리턴결과 : " + ks_Return_Model.결과);
                        // Console.WriteLine(SP명 + " 리턴값 : " + ks_Return_Model.Retrun값);

                        break;

                    case "hnbox":

                        hn_Access_Model.SP명 = SP명;
                        hn_Access_Model.파라미터 = 파라미터;
                        hn_Access_Model.값 = 값;
                        hn_DB_Handle_Model.프로시저 = new ServiceReference_hnbox.Access_Model[1] { hn_Access_Model };
                        hn_DB_Handle_Model.BroadCasting = 1;

                        hn_Return_Model = 갱신 == 1 ? hn_Service.갱신(hn_DB_Handle_Model, 갱신) : hn_Service.조회(hn_DB_Handle_Model);

                        returnModel.결과 = hn_Return_Model.결과;
                        returnModel.리턴값 = hn_Return_Model.Retrun값;

                        // Console.WriteLine(SP명 + " 리턴결과 : " + hn_Return_Model.결과);
                        // Console.WriteLine(SP명 + " 리턴값 : " + hn_Return_Model.Retrun값);

                        break;

                    case "shbox":
                        sh_Access_Model.SP명 = SP명;
                        sh_Access_Model.파라미터 = 파라미터;
                        sh_Access_Model.값 = 값;
                        sh_DB_Handle_Model.프로시저 = new ServiceReference_shbox.Access_Model[1] { sh_Access_Model };

                        sh_Return_Model = 갱신 == 1 ? sh_Service.갱신(sh_DB_Handle_Model, 갱신) : sh_Service.조회(sh_DB_Handle_Model);

                        returnModel.결과 = sh_Return_Model.결과;
                        returnModel.리턴값 = sh_Return_Model.Retrun값;
                        // Console.WriteLine(SP명 + " 리턴결과 : " + sh_Return_Model.결과);
                        // Console.WriteLine(SP명 + " 리턴값 : " + sh_Return_Model.Retrun값);
                        break;
                    case "kmbox":
                        km_Access_Model.SP명 = SP명;
                        km_Access_Model.파라미터 = 파라미터;
                        km_Access_Model.값 = 값;
                        km_DB_Handle_Model.프로시저 = new ServiceReference_kmbox.Access_Model[1] { km_Access_Model };
                        km_DB_Handle_Model.BroadCasting = 1;
                        km_Return_Model = 갱신 == 1 ? km_Service.갱신(km_DB_Handle_Model, 갱신) : km_Service.조회(km_DB_Handle_Model);
                        returnModel.결과 = km_Return_Model.결과;
                        returnModel.리턴값 = km_Return_Model.Retrun값;
                        //   Console.WriteLine(SP명 + " 리턴결과 : " + km_Return_Model.결과);
                        //  Console.WriteLine(SP명 + " 리턴값 : " + km_Return_Model.Retrun값);
                        break;

                    case "ycbox":

                        yc_Access_Model.SP명 = SP명;
                        yc_Access_Model.파라미터 = 파라미터;
                        yc_Access_Model.값 = 값;
                        yc_DB_Handle_Model.프로시저 = new ServiceReference_ycbox.Access_Model[1] { yc_Access_Model };
                        yc_DB_Handle_Model.BroadCasting = 1;

                        yc_Return_Model = 갱신 == 1 ? yc_Service.갱신(yc_DB_Handle_Model, 갱신) : yc_Service.조회(yc_DB_Handle_Model);

                        returnModel.결과 = yc_Return_Model.결과;
                        returnModel.리턴값 = yc_Return_Model.Retrun값;

                        Console.WriteLine(SP명 + " 리턴결과 : " + yc_Return_Model.결과);
                        Console.WriteLine(SP명 + " 리턴값 : " + yc_Return_Model.Retrun값);
                        break;
                    default:
                        break;
                }

            }

            catch (Exception)
            {
                returnModel.결과 = 0;
                returnModel.리턴값 = "";
            }

            return returnModel;
        }


        public static ReturnModel GetData(string serverIndex, string SP명, string[] 파라미터, object[] 값, int 갱신, string parameter)
        {
            ReturnModel returnModel = new ReturnModel();
            switch (serverIndex)
            {
                case "ojbox":
                    oj_Access_Model.SP명 = SP명;
                    oj_Access_Model.파라미터 = 파라미터;
                    oj_Access_Model.값 = 값;

                    oj_DB_Handle_Model.프로시저 = new ServiceReference_ojbox.Access_Model[1] { oj_Access_Model };
                    oj_DB_Handle_Model.BroadCasting = 1;
                    oj_DB_Handle_Model.BroadCastingName = "생산입력완료";
                    oj_DB_Handle_Model.inputPkey = "14201";
                    oj_DB_Handle_Model.inputContent = parameter;
                    oj_Return_Model = 갱신 == 1 ? oj_Service.갱신(oj_DB_Handle_Model, 갱신) : oj_Service.조회(oj_DB_Handle_Model);

                    returnModel.결과 = oj_Return_Model.결과;
                    returnModel.리턴값 = oj_Return_Model.Retrun값;
                    //  Console.WriteLine(SP명 + " 리턴결과 : " + mirae_Return_Model.결과);
                    //  Console.WriteLine(SP명 + " 리턴값 : " + mirae_Return_Model.Retrun값);

                    break;
                case "miraebox":
                    mirae_Access_Model.SP명 = SP명;
                    mirae_Access_Model.파라미터 = 파라미터;
                    mirae_Access_Model.값 = 값;

                    mirae_DB_Handle_Model.프로시저 = new ServiceReference_mirae.Access_Model[1] { mirae_Access_Model };
                    mirae_DB_Handle_Model.BroadCasting = 1;
                    mirae_DB_Handle_Model.BroadCastingName = "생산입력완료";
                    mirae_DB_Handle_Model.inputPkey = 14201;
                    mirae_DB_Handle_Model.inputContent = parameter;
                    mirae_Return_Model = 갱신 == 1 ? mirae_Service.갱신(mirae_DB_Handle_Model, 갱신) : mirae_Service.조회(mirae_DB_Handle_Model);

                    returnModel.결과 = mirae_Return_Model.결과;
                    returnModel.리턴값 = mirae_Return_Model.Retrun값;
                    //  Console.WriteLine(SP명 + " 리턴결과 : " + mirae_Return_Model.결과);
                    //  Console.WriteLine(SP명 + " 리턴값 : " + mirae_Return_Model.Retrun값);
                    break;

                case "ksbox":

                    ks_Access_Model.SP명 = SP명;
                    ks_Access_Model.파라미터 = 파라미터;
                    ks_Access_Model.값 = 값;

                    ks_DB_Handle_Model.프로시저 = new ServiceReference_ksbox.Access_Model[1] { ks_Access_Model };
                    ks_DB_Handle_Model.BroadCasting = 1;
                    ks_DB_Handle_Model.BroadCastingName = "생산입력완료";
                    ks_DB_Handle_Model.inputPkey = "14201";
                    ks_DB_Handle_Model.inputContent = parameter;
                    ks_Return_Model = 갱신 == 1 ? Ks_Service.갱신(ks_DB_Handle_Model, 갱신) : Ks_Service.조회(ks_DB_Handle_Model);

                    returnModel.결과 = ks_Return_Model.결과;
                    returnModel.리턴값 = ks_Return_Model.Retrun값;
                    //  Console.WriteLine(SP명 + " 리턴결과 : " + ks_Return_Model.결과);
                    //  Console.WriteLine(SP명 + " 리턴값 : " + ks_Return_Model.Retrun값);

                    break;

                case "hnbox":

                    hn_Access_Model.SP명 = SP명;
                    hn_Access_Model.파라미터 = 파라미터;
                    hn_Access_Model.값 = 값;
                    hn_DB_Handle_Model.프로시저 = new ServiceReference_hnbox.Access_Model[1] { hn_Access_Model };
                    hn_DB_Handle_Model.BroadCasting = 1;
                    hn_DB_Handle_Model.BroadCastingName = "생산입력완료";
                    hn_DB_Handle_Model.inputPkey = "14201";
                    hn_DB_Handle_Model.inputContent = parameter;
                    hn_Return_Model = 갱신 == 1 ? hn_Service.갱신(hn_DB_Handle_Model, 갱신) : hn_Service.조회(hn_DB_Handle_Model);

                    returnModel.결과 = hn_Return_Model.결과;
                    returnModel.리턴값 = hn_Return_Model.Retrun값;

                    //  Console.WriteLine(SP명 + " 리턴결과 : " + hn_Return_Model.결과);
                    //  Console.WriteLine(SP명 + " 리턴값 : " + hn_Return_Model.Retrun값);

                    break;

                case "shbox":

                    sh_Access_Model.SP명 = SP명;
                    sh_Access_Model.파라미터 = 파라미터;
                    sh_Access_Model.값 = 값;
                    sh_DB_Handle_Model.프로시저 = new ServiceReference_shbox.Access_Model[1] { sh_Access_Model };
                    sh_DB_Handle_Model.BroadCasting = 1;
                    sh_DB_Handle_Model.inputPkey = "14201";
                    sh_DB_Handle_Model.BroadCastingName = "생산입력완료";
                    sh_DB_Handle_Model.inputContent = parameter;

                    sh_Return_Model = 갱신 == 1 ? sh_Service.갱신(sh_DB_Handle_Model, 갱신) : sh_Service.조회(sh_DB_Handle_Model);

                    returnModel.결과 = sh_Return_Model.결과;
                    returnModel.리턴값 = sh_Return_Model.Retrun값;

                    //  Console.WriteLine(SP명 + " 리턴결과 : " + sh_Return_Model.결과);
                    //   Console.WriteLine(SP명 + " 리턴값 : " + sh_Return_Model.Retrun값);

                    break;
                case "kmbox":
                    km_Access_Model.SP명 = SP명;
                    km_Access_Model.파라미터 = 파라미터;
                    km_Access_Model.값 = 값;
                    km_DB_Handle_Model.프로시저 = new ServiceReference_kmbox.Access_Model[1] { km_Access_Model };
                    km_DB_Handle_Model.BroadCasting = 1;
                    km_DB_Handle_Model.inputPkey = "14201";
                    km_DB_Handle_Model.BroadCastingName = "생산입력완료";
                    km_DB_Handle_Model.inputContent = parameter;

                    km_Return_Model = 갱신 == 1 ? km_Service.갱신(km_DB_Handle_Model, 갱신) : km_Service.조회(km_DB_Handle_Model);

                    returnModel.결과 = km_Return_Model.결과;
                    returnModel.리턴값 = km_Return_Model.Retrun값;

                    // Console.WriteLine(SP명 + " 리턴결과 : " + km_Return_Model.결과);
                    //  Console.WriteLine(SP명 + " 리턴값 : " + km_Return_Model.Retrun값);

                    break;

                case "ycbox":
                    yc_Access_Model.SP명 = SP명;
                    yc_Access_Model.파라미터 = 파라미터;
                    yc_Access_Model.값 = 값;
                    yc_DB_Handle_Model.프로시저 = new ServiceReference_ycbox.Access_Model[1] { yc_Access_Model };
                    yc_DB_Handle_Model.BroadCasting = 1;
                    yc_DB_Handle_Model.inputPkey = "14201";
                    yc_DB_Handle_Model.BroadCastingName = "생산입력완료";
                    yc_DB_Handle_Model.inputContent = parameter;

                    yc_Return_Model = 갱신 == 1 ? yc_Service.갱신(yc_DB_Handle_Model, 갱신) : yc_Service.조회(yc_DB_Handle_Model);

                    returnModel.결과 = yc_Return_Model.결과;
                    returnModel.리턴값 = yc_Return_Model.Retrun값;

                    // Console.WriteLine(SP명 + " 리턴결과 : " + yc_Return_Model.결과);
                    //  Console.WriteLine(SP명 + " 리턴값 : " + yc_Return_Model.Retrun값);

                    break;
                default:
                    break;
            }
            return returnModel;
        }


    }
}
