﻿using System;
using System.ComponentModel;
using System.Windows.Controls;

namespace PopProject.Util
{
    /// <summary>
    /// ClsUc_완제품명세서_Control.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ClsUc_완제품명세서_Control3 : UserControl
    {
        public ProductReport ViewModel = new ProductReport();


        public ClsUc_완제품명세서_Control3()
        {
            InitializeComponent();

        }


        public void Set_BarCode()
        {
            DataContext = ViewModel;
        }

        public class ProductReport
        {
            public event PropertyChangedEventHandler PropertyChanged;
            public delegate void PropertyChangedEventHandler(object sender, PropertyChangedEventArgs e);

            protected virtual void OnPropertyChanged(string propName)
            {

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));

            }

            private string _customSName;
            public string CustomSName
            {
                get => _customSName;

                set
                {
                    _customSName = value;
                    OnPropertyChanged("customSName");
                }
            }

            private string _corpName;
            public string CorpName
            {
                get => _corpName;

                set
                {
                    _corpName = value;
                    OnPropertyChanged("corpName");
                }
            }

            private string _prodName;

            public string ProdName
            {

                get => _prodName;

                set
                {
                    _prodName = value;
                    OnPropertyChanged("prodName");
                }
            }

            private DateTime _orderLast;
            public DateTime OrderLast
            {
                get => _orderLast;
                set
                {
                    _orderLast = value;
                    OnPropertyChanged("orderLast");
                }
            }

            private string _pSize;
            public string PSize
            {
                get => _pSize;
                set
                {
                    _pSize = value;
                    OnPropertyChanged("pSize");
                }
            }

            private string _pMemo;
            public string PMemo
            {
                get => _pMemo;
                set
                {
                    _pMemo = value;
                    OnPropertyChanged("pMemo");
                }
            }

            private string _pworkDate;
            public string PworkDate
            {
                get => _pworkDate;
                set
                {
                    _pworkDate = value.Replace("-", "/");
                    OnPropertyChanged("pworkDate");
                }
            }

            private string _resultCount;
            public string ResultCount
            {
                get => _resultCount;
                set
                {
                    _resultCount = value;
                    OnPropertyChanged("resultCount");
                }
            }

            private string _pGol;
            public string PGol
            {
                get => _pGol;

                set
                {
                    _pGol = value.Replace("골", "");
                    OnPropertyChanged("pGol");
                }
            }


            private string _pStockKey;
            public string PStockKey
            {
                get => _pStockKey;

                set
                {
                    _pStockKey = value;
                    OnPropertyChanged("pStockKey");
                }
            }

            private string _MycustomSName;
            public string MycustomSName
            {

                get => _MycustomSName;

                set
                {
                    _MycustomSName = value;
                    OnPropertyChanged("MycustomSName");
                }
            }
        }
    }
}
