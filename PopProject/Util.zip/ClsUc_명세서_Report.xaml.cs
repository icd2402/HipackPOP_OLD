﻿using System;
using System.Collections.Generic;
using System.Linq;

using System.Windows.Controls;


namespace PopProject.Util
{
    /// <summary>
    /// ClsUc_명세서_Report.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class ClsUc_명세서_Report : UserControl
    {
        public ClsUc_명세서_Report()
        {
            InitializeComponent();
        }
    }
}
